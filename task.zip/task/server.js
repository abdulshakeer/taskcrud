const { Sequelize, DataTypes } = require('sequelize');
const express = require('express')

const app = express()

app.use(express.json())

app.get("/home",(req,res)=>{
    console.log("Welcome to home");
})

const sequelize = new Sequelize('dbdata', 'postgres', '12345', {
    host: 'localhost',
    dialect:"postgres" /* one of 'mysql' | 'postgres' | 'sqlite' | 'mariadb' | 'mssql' | 'db2' | 'snowflake' | 'oracle' */
  });

sequelize.authenticate().then(()=>{
    console.log('Connection has been established successfully.');

}).catch(()=>{
    console.error('Unable to connect to the database:', error);

})
  

  const Tasks = sequelize.define('Task', {
    // Model attributes are defined here
    taskName: {
      type: DataTypes.STRING,
      allowNull: false
    },
    description: {
      type: DataTypes.STRING
      // allowNull defaults to true
    },

  }, {
    // Other model options go here
    timestamps: true,
  });
  


  // Create the data

  app.post("/create",(req, res) => {
  
    const task = {
        taskName: req.body.taskName,
        description: req.body.description,    
    };
  
    Tasks.create(task)
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while creating the Task."
        });
      });
  });



  // Get All Tasks

  app.get("/findtask",(req,res)=>{
    Tasks.findAll()
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving tutorials."
      });
    });
  })

// Get One Task

app.get("/findOneTask/:id",(req,res)=>{
    const id = req.params.id;

    Tasks.findByPk(id)
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving tutorials."
      });
    });
  })


  // Update a Task

  app.put("/update/:id",(req,res)=>{
    const id = req.params.id;

    Tasks.update(req.body, {
        where: { id: id }
      })
    .then(data => {
      res.send("Updated Sucessfully");
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving tutorials."
      });
    });
  })

// Delete a Task

app.delete("/delete/:id",(req,res)=>{
    const id = req.params.id;

    Tasks.destroy({
        where: { id: id }
      })
    .then(data => {
      res.send("Deleted Sucessfully");
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving tutorials."
      });
    });
  })



  // Delete All Tasks

  app.delete("/deleteAll",(req,res)=>{

    Tasks.destroy({
        where: {},
        truncate: false

      })
    .then(data => {
      res.send("Deleted All Task Sucessfully");
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving tutorials."
      });
    });
  })

  sequelize.sync({ alter: true })
  .then(() => {
    console.log("database created");
  })
  .catch((error) => {
    console.log(error);
  })



  app.listen(8080,()=>{
    console.log("Running on port 3000");
  })